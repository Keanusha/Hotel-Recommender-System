from flask import Flask, jsonify, request
from flask_cors import CORS
import joblib
import pandas as pd

app = Flask(__name__)
CORS(app)


pipeline = joblib.load('hotel_model_pipeline.pkl')


df = pd.read_csv('C:/Users/94765/hotel/hotel.csv')
df.columns = df.columns.str.strip()

@app.route('/recommend', methods=['POST'])
def recommend_hotels():
    data = request.json
    location = data.get('location', '')

    if not location:
        return jsonify({'error': 'Location is required'}), 400

    try:
     
        filtered_df = df[df['Location'].str.contains(location, case=False, na=False)]

        if filtered_df.empty:
            return jsonify({'error': 'No hotels found for the given location'}), 404

        
        X = filtered_df[['Rating', 'Review', 'Location']]
        predictions = pipeline.predict(X)

        filtered_df['Predicted_Room_Type'] = predictions

        #Sort hotels by rating
        recommendations = filtered_df.sort_values(by='Rating', ascending=False)

      
        return jsonify(recommendations[['Name', 'Location', 'Rating', 'Review', 'Room_type', 'Predicted_Room_Type']].to_dict(orient='records'))

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000)

import pandas as pd
from pymongo import MongoClient

# MongoDB connection
client = MongoClient('mongodb://localhost:27017/')
db = client['hotel_recommender']
hotels_collection = db['hotels']

# Load the dataset
df = pd.read_csv('C:\\Users\\94765\\hotel\\hotel.csv')

# Strip leading/trailing spaces from column names (if any)
df.columns = df.columns.str.strip()

# Insert each row into the MongoDB collection
for _, row in df.iterrows():
    hotel = {
        'name': row['Name'],  
        'location': row['Location'],  
        'rating': row['Rating'],  
        'review_score': row['Review'], 
        'number_of_reviews': row['No_of_rooms'],  
        'room_type': row['Room_type']  
       
    }
    hotels_collection.insert_one(hotel)

print("Data imported successfully!")


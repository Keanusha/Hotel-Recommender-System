import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import joblib


df = pd.read_csv('C:/Users/94765/hotel/hotel.csv')

df.columns = df.columns.str.strip()


required_columns = ['Location', 'Review', 'Rating', 'Room_type']
missing_columns = [col for col in required_columns if col not in df.columns]
if missing_columns:
    raise ValueError(f"Missing columns in dataset: {', '.join(missing_columns)}")

# Preprocess data
df['Review'] = df['Review'].fillna('')
df['Rating'] = pd.to_numeric(df['Rating'], errors='coerce')
df = df.dropna(subset=['Rating', 'Location', 'Review'])

#Define feature and target variables
X = df[['Rating', 'Review', 'Location']]
y = df['Room_type'].astype('category').cat.codes


X = pd.DataFrame(X)
y = pd.Series(y)

#Preprocessing pipeline
preprocessor = ColumnTransformer(
    transformers=[
        ('rating', StandardScaler(), ['Rating']),
        ('text', TfidfVectorizer(max_features=5000), 'Review'),
        ('location', OneHotEncoder(handle_unknown='ignore'), ['Location'])
    ])

#Model pipeline
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', LogisticRegression(max_iter=2000, solver='lbfgs'))
])


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


pipeline.fit(X_train, y_train)

#Evaluate model
y_pred = pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy}')
print("Classification Report:\n", classification_report(y_test, y_pred))

#Save model pipeline
joblib.dump(pipeline, 'hotel_model_pipeline.pkl')
print("Model pipeline saved as 'hotel_model_pipeline.pkl'")

#Rank hotel function
def rank_hotels_by_location(location, pipeline):
    
    df = pd.read_csv('C:/Users/94765/hotel/hotel.csv')
  
    df.columns = df.columns.str.strip()

    
    required_columns = ['Location', 'Review', 'Rating', 'Name']
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        raise ValueError(f"Missing columns in dataset: {', '.join(missing_columns)}")

    #Filter by location
    df = df[df['Location'].str.contains(location, case=False, na=False)]
    if df.empty:
        return "No hotels found for the specified location."
    

    X = df[['Rating', 'Review', 'Location']]
    df['Predicted_Room_Type'] = pipeline.predict(X)
    
    #Rank hotels by rating
    df_sorted = df.sort_values(by='Rating', ascending=False)
    
    return df_sorted[['Name', 'Rating', 'Room_type']]


location = 'Phuket'
ranked_hotels = rank_hotels_by_location(location, pipeline)
print(ranked_hotels)

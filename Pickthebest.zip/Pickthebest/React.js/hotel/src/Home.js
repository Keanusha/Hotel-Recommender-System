import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const backgroundStyle = {
  backgroundImage: 'url(img2.jpeg)',
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  backgroundRepeat: 'no-repeat',
  height: '100vh',
  width: '100%',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'flex-start',
  alignItems: 'flex-start',
  color: 'white',
  textAlign: 'left',
  padding: '1rem',
  fontSize: '3.5rem',
};
const headingStyle = {
  position: 'relative',
  fontSize: '3rem', 
  fontWeight: 'bold',
  lineHeight: '1.2',
  textShadow: '2px 2px 4px rgba(0, 0, 0, 0.7)', 
  color: '#ffffff',
  zIndex: 2,
  marginBottom: '2rem', 
  top: '20%',
  left: '25%',

};
const searchBarStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  width: '40%',
  marginTop: '20px',
  position: 'absolute',
  top: '65%',
  left: '30%',
};

const inputStyle = {
  padding: '10px',
  border: 'none',
  borderRadius: '5px 0 0 5px',
  fontSize: '1.5rem',
  width: 'calc(100% - 110px)',
};

const buttonStyle = {
  padding: '10px',
  border: 'none',
  borderRadius: '0 5px 5px 0',
  backgroundColor: '#8B4513',
  color: 'white',
  fontWeight: 'bold',
  fontSize: '1.5rem',
  width: '100px',
  cursor: 'pointer',
};

const Home = () => {
  const [location, setLocation] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSearch = async () => {
    if (!location.trim()) {
      setError('Please enter a search query.');
      return;
    }
    
    setError('');
    setLoading(true);
    try {
      const response = await axios.post('/recommend', { location });
      navigate('/results', { state: { recommendations: response.data } });
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      setError('An error occurred while fetching recommendations.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={backgroundStyle}>
      <div style={headingStyle}>
      <h2>Let's Make Your Stay <br />The Best Ever!</h2>
      </div> 
      <div style={searchBarStyle}>
        <input
          type="text"
          placeholder="Where To?"
          style={inputStyle}
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          aria-label="Search for hotels"
        />
        <button
          style={buttonStyle}
          onClick={handleSearch}
          aria-label="Search"
        >
          Search
        </button>
      </div>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default Home;
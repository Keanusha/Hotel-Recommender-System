import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const Results = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { recommendations = [] } = location.state || {};

  console.log('Recommendations:', recommendations);

  const handleViewDetails = (hotel) => {
    navigate('/hotel-details', { state: { hotel } });
  };

  if (!recommendations.length) {
    return <p>No results found</p>;
  }

  return (
    <div style={{ padding: '20px', fontFamily: '"Playfair Display", serif' }}>
      <h2 style={{ marginBottom: '20px' }}>Hotels Found!</h2>
      <ul style={{ listStyle: 'none', padding: '0' }}>
        {recommendations.map((hotel, index) => (
          <li
            key={index}
            style={{
              marginBottom: '15px',
              display: 'flex',
              alignItems: 'center',
              borderBottom: '1px solid #ddd',
              paddingBottom: '10px',
              justifyContent: 'space-between',
              paddingRight: '10px',
            }}
          >
            <strong
              style={{
                flex: 1,
                marginRight: '10px',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                fontSize: '1.2rem',
                color: '#333',
                fontWeight: 'bold',
              }}
            >
              {hotel.Name} 
            </strong>
            <button
              onClick={() => handleViewDetails(hotel)}
              style={{
                padding: '8px 16px',
                border: 'none',
                borderRadius: '5px',
                backgroundColor: '#8B4513',
                color: 'white',
                width: '120px',
                fontWeight: 'bold',
                fontSize: '0.9rem',
                cursor: 'pointer',
              }}
            >
              View Details
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Results;

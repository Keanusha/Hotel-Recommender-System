import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const userData = { email, password };
      const response = await axios.post('http://localhost:3001/api/login', userData);

      alert('Login successful');
      localStorage.setItem('token', response.data.token);
      navigate('/');
    } catch (error) {
      console.error('Error logging in:', error.response?.data?.message || error.message);
      alert('Invalid email or password');
    }
  };

  return (
    <div style={styles.loginContainer}>
      <div style={styles.formContainer}>
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <div style={styles.inputGroup}>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter Your Email"
              required
              style={styles.input}
            />
          </div>
          <div style={styles.inputGroup}>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter Password"
              required
              style={styles.input}
            />
          </div>
          <button type="submit" style={styles.button}>Login</button>
        </form>
        <p style={styles.paragraph}>
          Don't have an account? <a href="/register" style={styles.link}>Register</a>
        </p>
      </div>
    </div>
  );
};

const styles = {
  loginContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    width: '100%',
    backgroundImage: 'url("img2.jpeg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundColor: '#f0f0f0',
    margin: '0',
    padding: '0',
  },
  formContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: '2rem',
    borderRadius: '10px',
    textAlign: 'center',
    maxWidth: '400px',
    width: '100%',
    boxSizing: 'border-box',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
  },
  inputGroup: {
    marginBottom: '1rem',
  },
  input: {
    padding: '0.5rem',
    fontSize: '1rem',
    width: '100%',
    boxSizing: 'border-box',
    marginBottom: '1rem',
    color: '#333',
    backgroundColor: '#f8f8f8',
    border: '1px solid #ccc',
    borderRadius: '5px',
  },
  button: {
    padding: '0.8rem 1.5rem',
    fontSize: '1.2rem',
    backgroundColor: '#8b4513',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    marginBottom: '1rem',
    borderRadius: '5px',
  },
  paragraph: {
    fontSize: '0.9rem',
    color: '#333',
  },
  link: {
    color: '#333',
    textDecoration: 'underline',
    cursor: 'pointer',
  },
};

export default Login;

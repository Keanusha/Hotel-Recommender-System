import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const NavigationBar = () => {
  const location = useLocation(); 
  const currentPath = location.pathname; 

  const navbarStyle = {
    backgroundColor: 'white', 
    color: 'black',
    display: 'flex',
    justifyContent: 'space-between',
    fontFamily: 'Montserrat, sans-serif',
    alignItems: 'center',
    padding: '1rem',
    position: 'fixed',
    top: 0,
    width: '100%',
    overflowX: 'hidden',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', 
  };

  const logoStyle = {
    color: 'Black', 
    fontWeight: 'bold',
    fontSize: '2rem',
    marginLeft: '20px',
  };

  const linkContainerStyle = {
    display: 'flex',
    marginLeft: '-1rem',
  };

  const linkStyle = {
    margin: '0 1rem',
    color: 'black',
    textDecoration: 'none',
    fontSize: '1.3rem',
    padding: '0.5rem', 
  };

  const activeLinkStyle = {
    ...linkStyle,
    color: '#8B4513', 
    fontWeight: 'bold',
    borderBottom: '2px solid #8B4513', 
  };

  return (
    <nav style={navbarStyle}>
      <div style={logoStyle}>PickTheBest</div>
      <div style={linkContainerStyle}>
        <Link to="/" style={currentPath === '/' ? activeLinkStyle : linkStyle}>Home</Link>
        <Link to="/login" style={currentPath === '/login'|| currentPath === '/register'? activeLinkStyle : linkStyle}>Profile</Link>
        <Link to="/explore" style={currentPath === '/explore' ? activeLinkStyle : linkStyle}>Explore</Link>
        <Link to="/contact-us" style={currentPath === '/contact-us' ? activeLinkStyle : linkStyle}>Contact Us</Link>
        
      </div>
    </nav>
  );
};

export default NavigationBar;

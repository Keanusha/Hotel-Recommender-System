import React, { useState, useEffect } from 'react';
import gsap from 'gsap';


const hotels = [
  {
    id: 1,
    location: 'The Leaf Oceanside by Katathani',
    image: 'https://i.content4travel.com/cms/img/u/desktop/se/hktleaf_6.jpg?version=180508-04?version=180628-08',
    description: 'Experience luxurious rooms with stunning ocean views. Room types include Deluxe, Suite, and Villa.'
  },
  {
    id: 2,
    location: 'Combo Beach Hotel Samui',
    image: 'https://isratours.net/wp-content/uploads/2018/08/combo-beach-club-samui-1.jpg',
    description: 'Enjoy beachfront luxury with modern amenities. Room options include Standard, Deluxe, and Family Rooms.'
  },
  {
    id: 3,
    location: 'Krabi La Playa Resort - SHA Plus',
    image: 'https://pix10.agoda.net/hotelImages/48397/-1/382d084db56ba271ea93f85988b6495b.jpg?ca=7&ce=1&s=1024x768',
    description: 'Relax in our tropical paradise with a range of room types, including Garden View and Pool Access Rooms.'
  },
  {
    id: 4,
    location: 'Paradise Resort Phi Phi-SHA Plus',
    image: 'https://q-xx.bstatic.com/xdata/images/hotel/840x460/85812081.jpg?k=00093d9c4e81f9c8dba63e47a773671fee9070222fb0c555f7f2357175ba43d2&o=&isSkia=true',
    description: 'Discover an idyllic escape with rooms offering breathtaking sea views and premium amenities.'
  },
  {
    id: 5,
    location: 'Armoni Patong Beach Hotel',
    image: 'https://safarmarket.com/blog/data/uploaded_files/dcece6af6ad6d77d37f52def.jpg',
    description: 'Stay in comfort with well-appointed rooms close to Patong Beach. Choose from Standard, Deluxe, or Suite options.'
  },
];

const Explore = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    gsap.fromTo(
      '.hotel-image',
      { scale: 0.8, opacity: 0 },
      { scale: 1, opacity: 1, duration: 1, ease: 'power2.out' }
    );
    gsap.fromTo(
      '.hotel-title',
      { y: 50, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, ease: 'power2.out', delay: 1 }
    );
    gsap.fromTo(
      '.hotel-description',
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, ease: 'power2.out', delay: 1.5 }
    );
  }, [currentIndex]);

  const handleThumbnailClick = (index) => {
    setCurrentIndex(index);
  };

  return (
    <div style={styles.explorePage}>
      <div style={styles.sliderContainer}>
        <img
          src={hotels[currentIndex].image}
          alt={hotels[currentIndex].location}
          className="hotel-image"
          style={styles.hotelImage}
        />
        <div style={styles.hotelInfo}>
          <h2 className="hotel-title" style={styles.hotelTitle}>{hotels[currentIndex].location}</h2>
          <p className="hotel-description" style={styles.hotelDescription}>{hotels[currentIndex].description}</p>
        </div>
      </div>
      <div style={styles.thumbnailContainer}>
        {hotels.map((hotel, index) => (
          <img
            key={hotel.id}
            src={hotel.image}
            alt={hotel.location}
            onClick={() => handleThumbnailClick(index)}
            style={{
              ...styles.thumbnail,
              border: index === currentIndex ? '2px solid #8B4513' : '2px solid transparent',
            }}
          />
        ))}
      </div>
    </div>
  );
};

// Inline styles
const styles = {
  explorePage: {
    padding: '0',
    margin: '0',
    height: '100vh',
    width: '100%',
    position: 'relative',
    overflow: 'hidden',
    backgroundColor: '#f5f5f5',
    fontFamily: '"Roboto", sans-serif', 
  },
  sliderContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '80%',
    width: '100%',
    position: 'relative',
    overflow: 'hidden',
  },
  hotelImage: {
    width: '100%',
    height: 'auto',
    objectFit: 'cover',
    transition: 'transform 1s ease-in-out',
  },
  hotelInfo: {
    position: 'absolute',
    bottom: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    color: '#000',
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 0 10px rgba(0,0,0,0.3)',
    width: '80%',
    textAlign: 'center',
    opacity: 1,
    transition: 'opacity 1s ease-in-out',
  },
  hotelTitle: {
    fontSize: '2.5rem',
    fontWeight: 'bold',
    margin: '0',
    color: '#333',
    fontFamily: '"Playfair Display", serif', 
  },
  hotelDescription: {
    fontSize: '1.2rem',
    margin: '10px 0 0 0',
    color: '#8B4513',
    fontFamily: '"Roboto", sans-serif', 
  },
  thumbnailContainer: {
    display: 'flex',
    justifyContent: 'center',
    gap: '10px',
    padding: '10px',
    overflowX: 'auto',
    backgroundColor: '#fff',
    boxShadow: '0 -2px 5px rgba(0,0,0,0.1)',
  },
  thumbnail: {
    width: '100px',
    height: 'auto',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'border 0.3s ease',
  },
};

export default Explore;

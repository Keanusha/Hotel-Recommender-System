import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Modal from './Modal'; 

const HotelDetails = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { hotel } = location.state || {};

    const [checkInDate, setCheckInDate] = useState('');
    const [checkOutDate, setCheckOutDate] = useState('');
    const [numberOfRooms, setNumberOfRooms] = useState(1);
    const [reservationMessage, setReservationMessage] = useState('');

    if (!hotel) {
        return <p>No hotel data available</p>;
    }

    const handleReserve = () => {
        if (checkInDate && checkOutDate) {
            setReservationMessage('Reservation confirmed successfully!');
        } else {
            setReservationMessage('Please fill in all required fields.');
        }
    };

    const handleAddReview = () => {
        navigate('/review', { state: { hotelId: hotel._id } });
    };
    

    const handleCloseModal = () => {
        setReservationMessage('');
    };

    const styles = {
        page: {
            height: '100vh',
            width: '100vw',
            backgroundImage: 'url(https://img.freepik.com/premium-photo/abstract-blur-hotel-lobby-interior-background_729149-20600.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
        },
        container: {
            padding: '30px',
            backgroundColor: '#FAF0E6',
            borderRadius: '8px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
            width: '600px', 
            maxWidth: '1000px',
            margin: '0 auto',
            display: 'flex',
            flexDirection: 'row',
            gap: '20px',
        },
        details: {
            flex: 2,
            display: 'flex',
            flexDirection: 'column',
            paddingRight: '20px',
            borderRight: '1px solid #ddd',
        },
        form: {
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
        },
        heading: {
            fontSize: '2rem', 
            marginBottom: '15px',
            color: '#333',
            borderBottom: '2px solid #8B4513',
            paddingBottom: '10px',
            wordWrap: 'break-word', 
        },
        paragraph: {
            fontSize: '1.1rem',
            margin: '8px 0',
            color: '#666',
        },
        button: {
            padding: '12px 20px',
            fontSize: '1rem',
            color: '#fff',
            backgroundColor: '#8B4513',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            margin: '5px 0',
        },
        formGroup: {
            marginBottom: '20px',
        },
        label: {
            display: 'block',
            marginBottom: '5px',
            fontSize: '1rem',
            color: '#333',
        },
        input: {
            padding: '10px',
            fontSize: '1rem',
            borderRadius: '5px',
            border: '1px solid #ddd',
            width: '100%',
        },
    };
    

    return (
        <div style={styles.page}>
            <div style={styles.container}>
                <div style={styles.details}>
                    <h1 style={styles.heading}>{hotel.Name}</h1>
                    <p style={styles.paragraph}>Location: {hotel.Location}</p>
                    <p style={styles.paragraph}>Rating: {hotel.Rating}</p>
                    <p style={styles.paragraph}>Review: {hotel.Review}</p>
                    <p style={styles.paragraph}>Number of Rooms: {hotel.No_of_rooms}</p>
                    <p style={styles.paragraph}>Room Type: {hotel.Room_type}</p>
                </div>
                <div style={styles.form}>
                    <div style={styles.formGroup}>
                        <label style={styles.label}>Check-in Date</label>
                        <input
                            type="date"
                            value={checkInDate}
                            onChange={(e) => setCheckInDate(e.target.value)}
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.formGroup}>
                        <label style={styles.label}>Check-out Date</label>
                        <input
                            type="date"
                            value={checkOutDate}
                            onChange={(e) => setCheckOutDate(e.target.value)}
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.formGroup}>
                        <label style={styles.label}>Number of Rooms</label>
                        <input
                            type="number"
                            min="1"
                            value={numberOfRooms}
                            onChange={(e) => setNumberOfRooms(e.target.value)}
                            style={styles.input}
                        />
                    </div>
                    <button
                        style={styles.button}
                        onClick={handleReserve}
                        disabled={!checkInDate || !checkOutDate}
                    >
                        Reserve
                    </button>
                    <button
                        style={styles.button}
                        onClick={handleAddReview}
                    >
                        Add Review
                    </button>
                </div>
            </div>
            <Modal message={reservationMessage} onClose={handleCloseModal} />
        </div>
    );
};

export default HotelDetails;

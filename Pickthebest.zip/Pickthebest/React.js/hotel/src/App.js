// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import NavigationBar from './NavigationBar';
import Home from './Home';
import Login from './Login';
import Explore from './Explore';
import Register from './Register';
import ContactUs from './ContactUs';
import Results from './Results'; 
import HotelDetails from './HotelDetails';
import './App.css';
import ReviewPage from './ReviewPage';


const App = () => {
  return (
    <Router>
      <div className="App">
        <NavigationBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/register" element={<Register />} />
          <Route path="/contact-us" element={<ContactUs />} />
          <Route path="/results" element={<Results />} /> 
          <Route path="/hotel-details" element={<HotelDetails />} />
          <Route path="/review" element={<ReviewPage />} />
          
        </Routes>
      </div>
    </Router>
  );
};

export default App;

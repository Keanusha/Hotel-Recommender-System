import React, { useState } from 'react';

const ReviewPage = () => {
    const [textReview, setTextReview] = useState('');
    const [isRecording, setIsRecording] = useState(false);
    const [recognition, setRecognition] = useState(null);
    const [rating, setRating] = useState(0);
    const [hoverRating, setHoverRating] = useState(0);

    const handleTextChange = (e) => {
        setTextReview(e.target.value);
    };

    const handleMicClick = () => {
        if (!isRecording) {
            startRecording();
        } else {
            stopRecording();
        }
    };

    const startRecording = () => {
        const recognitionInstance = new window.webkitSpeechRecognition();
        recognitionInstance.continuous = true;
        recognitionInstance.interimResults = true;

        recognitionInstance.onresult = (event) => {
            for (let i = event.resultIndex; i < event.results.length; i++) {
                if (event.results[i].isFinal) {
                    setTextReview((prevText) => prevText + event.results[i][0].transcript);
                }
            }
        };

        recognitionInstance.start();
        setRecognition(recognitionInstance);
        setIsRecording(true);
    };

    const stopRecording = () => {
        if (recognition) {
            recognition.stop();
        }
        setIsRecording(false);
    };

    const handleStarClick = (value) => {
        setRating(value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const reviewData = new FormData();
        reviewData.append('review', textReview);
        reviewData.append('rating', rating);

        try {
            const response = await fetch('http://localhost:3001/api/reviews', {
                method: 'POST',
                body: reviewData,
            });
            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.message || 'Network response was not ok');
            }
            alert('Review submitted successfully!');
        } catch (error) {
            console.error('Failed to submit review:', error);
            alert('Failed to submit review');
        }
    };

    const styles = {
        page: {
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100vh',
            backgroundColor: '#f0f4f8',
        },
        container: {
            backgroundColor: '#ffffff',
            padding: '30px',
            borderRadius: '10px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
            width: '600px',
            textAlign: 'center',
        },
        heading: {
            fontSize: '1.5rem',
            marginBottom: '20px',
        },
        starRating: {
            display: 'flex',
            justifyContent: 'center',
            marginBottom: '20px',
        },
        star: {
            fontSize: '2rem',
            cursor: 'pointer',
            color: '#d3d3d3',
        },
        starFilled: {
            color: '#FFD700',
        },
        textarea: {
            width: '100%',
            height: '120px',
            padding: '12px',
            fontSize: '1rem',
            borderRadius: '8px',
            border: '1px solid #ddd',
            boxSizing: 'border-box',
            backgroundColor: '#f5f5f5',
        },
        micButton: {
            backgroundImage: 'url(/mic.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            border: 'none',
            borderRadius: '50%',
            width: '50px',
            height: '50px',
            cursor: 'pointer',
            backgroundColor: isRecording ? 'red' : 'gray',
        },
        submitButton: {
            backgroundColor: '#8B4513',
            color: '#fff',
            border: 'none',
            padding: '10px 20px',
            borderRadius: '5px',
            cursor: 'pointer',
        },
    };

    return (
        <div style={styles.page}>
            <div style={styles.container}>
                <h1 style={styles.heading}>Leave a review</h1>
                <div style={styles.starRating}>
                    {[1, 2, 3, 4, 5].map((value) => (
                        <span
                            key={value}
                            style={{
                                ...styles.star,
                                ...(hoverRating >= value || rating >= value ? styles.starFilled : {}),
                            }}
                            onClick={() => handleStarClick(value)}
                            onMouseEnter={() => setHoverRating(value)}
                            onMouseLeave={() => setHoverRating(rating)}
                        >
                            ★
                        </span>
                    ))}
                </div>
                <textarea
                    style={styles.textarea}
                    value={textReview}
                    onChange={handleTextChange}
                    placeholder="Write your review here..."
                />
                <div>
                    <button
                        style={styles.micButton}
                        onClick={handleMicClick}
                        title="Press this microphone to add an audio review"
                        aria-label={isRecording ? 'Stop Recording' : 'Start Recording'}
                    />
                </div>
                <button style={styles.submitButton} onClick={handleSubmit}>
                    Submit Review
                </button>
            </div>
        </div>
    );
};

export default ReviewPage;

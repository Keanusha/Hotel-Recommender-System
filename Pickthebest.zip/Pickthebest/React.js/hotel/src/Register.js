import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    
    if (password !== confirmPassword) {
      console.error("Passwords don't match");
      alert("Passwords don't match");
      return;
    }

    try {
      const userData = { name, email, password };
      await axios.post('http://localhost:3001/api/register', userData);

      alert('User registered successfully');
      navigate('/login');
    } catch (error) {
      
      console.error('Error registering user:', error);

     
      if (error.response) {
       
        console.error('Error response data:', error.response.data);
        alert(`Error: ${error.response.data.message || 'Registration failed'}`);
      } else if (error.request) {
        
        console.error('Error request:', error.request);
        alert('No response from server');
      } else {
        
        console.error('Error message:', error.message);
        alert('Error: ' + error.message);
      }
    }
  };

  const registerContainerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    width: '100vw',
    backgroundImage: 'url("img2.jpeg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundColor: '#f0f0f0',
    margin: 0,
    padding: 0,
  };

  const formStyle = {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: '2rem',
    borderRadius: '10px',
    textAlign: 'center',
    maxWidth: '400px',
    width: '100%',
    boxSizing: 'border-box',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
  };

  const inputGroupStyle = {
    marginBottom: '1rem',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  };

  const inputStyle = {
    padding: '0.5rem',
    fontSize: '1rem',
    width: '100%',
    boxSizing: 'border-box',
    marginBottom: '1rem',
    color: '#333',
    backgroundColor: '#f8f8f8',
    border: '1px solid #ccc',
    borderRadius: '5px',
  };

  const buttonStyle = {
    padding: '0.8rem 1.5rem',
    fontSize: '1.2rem',
    backgroundColor: '#8B4513',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    marginBottom: '1rem',
    borderRadius: '5px',
  };

  const loginLinkStyle = {
    color: '#333',
    textDecoration: 'underline',
    cursor: 'pointer',
  };

  return (
    <div style={registerContainerStyle}>
      <div style={formStyle}>
        <h2 style={{ marginBottom: '1.5rem' }}>Register</h2>
        <form onSubmit={handleSubmit}>
          <div style={inputGroupStyle}>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter Your Name"
              style={inputStyle}
              required
            />
          </div>
          <div style={inputGroupStyle}>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter Your Email"
              style={inputStyle}
              required
            />
          </div>
          <div style={inputGroupStyle}>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter Password"
              style={inputStyle}
              required
            />
          </div>
          <div style={inputGroupStyle}>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm Password"
              style={inputStyle}
              required
            />
          </div>
          <button type="submit" style={buttonStyle}>Register</button>
        </form>
        <p style={{ fontSize: '0.9rem', color: '#333' }}>
          Already have an account? <a href="/login" style={loginLinkStyle}>Login</a>
        </p>
      </div>
    </div>
  );
};

export default Register;

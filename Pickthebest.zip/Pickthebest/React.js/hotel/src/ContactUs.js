import React, { useState } from 'react';
import axios from 'axios';

const AboutUs = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });


  const aboutUsStyle = {
    padding: '60px 20px',
    textAlign: 'center',
    fontFamily: 'Arial, sans-serif',
    color: '#333',
    backgroundColor: '#f8f8f8',
    
  };

  const sectionStyle = {
    marginBottom: '60px',
  };

  const headingStyle = {
    fontSize: '2.5rem',
    fontWeight: 'bold',
    marginBottom: '20px',
    color: '#333',
  };

  const subHeadingStyle = {
    fontSize: '1.8rem',
    fontWeight: '600',
    marginBottom: '20px',
    color: '#555',
  };

  const textStyle = {
    fontSize: '1.2rem',
    lineHeight: '1.8',
    color: '#555',
    maxWidth: '800px',
    margin: '0 auto',
  };

  const contactFormStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: '30px',
    borderRadius: '8px',
    boxShadow: '0 6px 12px rgba(0, 0, 0, 0.1)',
  };

  const inputStyle = {
    padding: '12px',
    marginBottom: '15px',
    width: '100%',
    boxSizing: 'border-box',
    border: '1px solid #ddd',
    borderRadius: '5px',
  };

  const textareaStyle = {
    padding: '12px',
    marginBottom: '20px',
    width: '100%',
    height: '150px',
    resize: 'vertical',
    boxSizing: 'border-box',
    border: '1px solid #ddd',
    borderRadius: '5px',
  };

  const buttonStyle = {
    padding: '14px',
    width: '100%',
    backgroundColor: '#333',
    color: '#FFF',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    fontSize: '1rem',
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/api/contact', form);
      alert(response.data.message);
      setForm({ name: '', email: '', message: '' });
    } catch (error) {
      alert('Error submitting the form');
    }
  };

  return (
    
    <div style={aboutUsStyle}>
      <h1 style={headingStyle}> </h1>
      <div style={sectionStyle}>
        <h2 style={subHeadingStyle}>Our Mission</h2>
        <p style={textStyle}>
          At PickTheBest, our mission is to provide travelers with personalized hotel recommendations
          based on their preferences, ensuring a delightful and memorable stay experience.
        </p>
      </div>
      <div style={sectionStyle}>
        <h2 style={subHeadingStyle}>Our Team</h2>
        <p style={textStyle}>
          Meet the dedicated team behind PickTheBest. We are passionate about travel and technology,
          striving to create innovative solutions for your accommodation needs.
        </p>
      </div>
      <div style={sectionStyle}>
        <h2 style={subHeadingStyle}>Contact Us</h2>
        <p style={textStyle}>
          Have questions or feedback? Reach out to us at <a href="mailto:support@pickthebest.com" style={{ color: '#333' }}>support@pickthebest.com</a>. We're here to assist
          you in making the most out of your travel adventures.
        </p>
        <div style={contactFormStyle}>
          <h3 style={headingStyle}>Contact Form</h3>
          <form onSubmit={handleSubmit} style={{ width: '100%', maxWidth: '400px' }}>
            <input
              type="text"
              placeholder="Your Name"
              style={inputStyle}
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
            <input
              type="email"
              placeholder="Your Email"
              style={inputStyle}
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
            <textarea
              placeholder="Your Message"
              style={textareaStyle}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              required
            ></textarea>
            <button type="submit" style={buttonStyle}>Send Message</button>
          </form>
        </div>
      </div>
    </div>
   
  );
};

export default AboutUs;